import React from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { MusicProvider } from "./contexts/MusicContext";
import { Toaster } from "sonner";

// Pages
import EntryPage from "./pages/EntryPage";
import NoPage from "./pages/NoPage";
import IKnewItPage from "./pages/IKnewItPage";
import ProposalPage from "./pages/ProposalPage";
import RetryPage from "./pages/RetryPage";
import CelebrationPage from "./pages/CelebrationPage";
import RosesPage from "./pages/RosesPage";
import GalleryPage from "./pages/GalleryPage";
import CertificatePage from "./pages/CertificatePage";
import AdminDashboard from "./pages/AdminDashboard";

function App() {
  return (
    <MusicProvider>
      <div className="App">
        <Toaster position="top-center" richColors />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<EntryPage />} />
            <Route path="/no-page" element={<NoPage />} />
            <Route path="/i-knew-it" element={<IKnewItPage />} />
            <Route path="/proposal" element={<ProposalPage />} />
            <Route path="/retry" element={<RetryPage />} />
            <Route path="/celebration" element={<CelebrationPage />} />
            <Route path="/gift/roses" element={<RosesPage />} />
            <Route path="/gift/gallery" element={<GalleryPage />} />
            <Route path="/gift/certificate" element={<CertificatePage />} />
            <Route path="/admin" element={<AdminDashboard />} />
          </Routes>
        </BrowserRouter>
      </div>
    </MusicProvider>
  );
}

export default App;
