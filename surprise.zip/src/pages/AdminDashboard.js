import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Upload, Save, Trash2, Home, Image, Music, FileText } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('content');
  const [contents, setContents] = useState({});
  const [media, setMedia] = useState({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchAllData();
  }, []);

  const fetchAllData = async () => {
    try {
      const [contentsRes, mediaRes] = await Promise.all([
        axios.get(`${API}/content`),
        axios.get(`${API}/media`)
      ]);

      const contentsMap = {};
      contentsRes.data.forEach(item => {
        contentsMap[item.key] = item.value;
      });
      setContents(contentsMap);

      const mediaMap = {};
      mediaRes.data.forEach(item => {
        mediaMap[item.key] = item.url;
      });
      setMedia(mediaMap);
    } catch (err) {
      console.error('Error fetching data:', err);
    }
  };

  const handleContentSave = async (key, value) => {
    try {
      setLoading(true);
      await axios.post(`${API}/content`, { key, value });
      toast.success('Content saved successfully!');
      fetchAllData();
    } catch (err) {
      toast.error('Failed to save content');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleMediaUpload = async (key, file) => {
    if (!file) return;

    try {
      setLoading(true);
      const formData = new FormData();
      formData.append('key', key);
      formData.append('file', file);

      await axios.post(`${API}/media`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      
      toast.success('Media uploaded successfully!');
      fetchAllData();
    } catch (err) {
      toast.error('Failed to upload media');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleMediaDelete = async (key) => {
    try {
      setLoading(true);
      await axios.delete(`${API}/media/${key}`);
      toast.success('Media deleted successfully!');
      fetchAllData();
    } catch (err) {
      toast.error('Failed to delete media');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const ContentEditor = ({ label, contentKey, placeholder, isTextarea = false }) => {
    const [value, setValue] = useState(contents[contentKey] || '');

    useEffect(() => {
      setValue(contents[contentKey] || '');
    }, [contents, contentKey]);

    return (
      <div className="mb-6">
        <label className="block text-sm font-semibold text-gray-700 mb-2">
          {label}
        </label>
        {isTextarea ? (
          <textarea
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder={placeholder}
            className="w-full px-4 py-3 border-2 border-pink-200 rounded-xl focus:border-pink-400 focus:outline-none resize-none"
            rows={4}
            data-testid={`content-input-${contentKey}`}
          />
        ) : (
          <input
            type="text"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder={placeholder}
            className="w-full px-4 py-3 border-2 border-pink-200 rounded-xl focus:border-pink-400 focus:outline-none"
            data-testid={`content-input-${contentKey}`}
          />
        )}
        <button
          onClick={() => handleContentSave(contentKey, value)}
          disabled={loading}
          className="mt-2 bg-gradient-to-r from-pink-400 to-purple-400 text-white px-6 py-2 rounded-full shadow-lg hover:shadow-xl disabled:opacity-50 flex items-center gap-2"
          data-testid={`save-content-${contentKey}`}
        >
          <Save size={16} />
          Save
        </button>
      </div>
    );
  };

  const MediaUploader = ({ label, mediaKey, accept = "image/*" }) => {
    const [preview, setPreview] = useState(media[mediaKey] || null);

    useEffect(() => {
      setPreview(media[mediaKey] || null);
    }, [media, mediaKey]);

    const handleFileSelect = (e) => {
      const file = e.target.files[0];
      if (file) {
        handleMediaUpload(mediaKey, file);
      }
    };

    return (
      <div className="mb-6 bg-gray-50 p-4 rounded-xl">
        <label className="block text-sm font-semibold text-gray-700 mb-2">
          {label}
        </label>
        
        {preview && (
          <div className="mb-4 relative">
            {accept.includes('audio') ? (
              <audio controls src={preview} className="w-full" data-testid={`media-preview-${mediaKey}`} />
            ) : (
              <img
                src={preview}
                alt={label}
                className="w-full h-48 object-cover rounded-lg"
                data-testid={`media-preview-${mediaKey}`}
              />
            )}
            <button
              onClick={() => handleMediaDelete(mediaKey)}
              className="absolute top-2 right-2 bg-red-500 text-white p-2 rounded-full shadow-lg hover:bg-red-600"
              data-testid={`delete-media-${mediaKey}`}
            >
              <Trash2 size={16} />
            </button>
          </div>
        )}

        <label className="cursor-pointer bg-white border-2 border-dashed border-pink-300 rounded-xl p-6 flex flex-col items-center justify-center hover:border-pink-400 transition-colors">
          <Upload className="text-pink-400 mb-2" size={32} />
          <span className="text-sm text-gray-600">Click to upload</span>
          <input
            type="file"
            accept={accept}
            onChange={handleFileSelect}
            className="hidden"
            data-testid={`upload-input-${mediaKey}`}
          />
        </label>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 to-purple-100 p-4">
      <div className="max-w-6xl mx-auto py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold dancing-script text-pink-600" data-testid="admin-title">
            Admin Dashboard 💕
          </h1>
          <motion.button
            onClick={() => navigate('/')}
            className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-lg hover:shadow-xl"
            whileHover={{ scale: 1.05 }}
            data-testid="home-button"
          >
            <Home size={20} />
            <span className="font-semibold">View Site</span>
          </motion.button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto">
          {[
            { id: 'content', label: 'Text Content', icon: FileText },
            { id: 'media', label: 'Images & GIFs', icon: Image },
            { id: 'gallery', label: 'Gallery', icon: Image },
            { id: 'audio', label: 'Audio', icon: Music }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-6 py-3 rounded-full font-semibold transition-all ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-pink-400 to-purple-400 text-white shadow-lg'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
              data-testid={`tab-${tab.id}`}
            >
              <tab.icon size={18} />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content Sections */}
        <div className="bg-white rounded-3xl p-8 shadow-2xl">
          {activeTab === 'content' && (
            <div data-testid="content-section">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Edit Text Content</h2>
              
              <ContentEditor
                label="Entry Page Text (Use {name} for dynamic name)"
                contentKey="entry_page"
                placeholder="Hey {name} 🥹 I made something for youuu… wanna see? 💌|Harshuu"
              />
              
              <ContentEditor
                label="NO Page Text"
                contentKey="no_page"
                placeholder="HOW DARE YOUUUU 😤💔"
              />
              
              <ContentEditor
                label="I Knew It Page Text"
                contentKey="i_knew_it_page"
                placeholder="YAYAYAA I knew you would click that 😌 That's my girl 💖"
              />
              
              <ContentEditor
                label="Proposal Page Text (Use {name} for dynamic name)"
                contentKey="proposal_page"
                placeholder="{name}… will you be mainee? 🥹👉🏻👈🏻💍|Harshika"
              />
              
              <ContentEditor
                label="Retry Page Text"
                contentKey="retry_page"
                placeholder="Did you just say nooo bachaaa 🥺💔"
              />
              
              <ContentEditor
                label="Celebration Page Text"
                contentKey="celebration_page"
                placeholder="YAYAYAYAY MWAHHHHH MY KUCHU PUCHUUUU 🥹🥀💋\nHERE'S YOUR GIFT 🎁"
                isTextarea
              />
              
              <ContentEditor
                label="Roses Love Letter"
                contentKey="roses_letter"
                placeholder="My dearest love,\n\nYou are my everything..."
                isTextarea
              />
              
              <ContentEditor
                label="Gallery Messages (Separate with |||)"
                contentKey="gallery_messages"
                placeholder="Every moment with you is magical ✨|||You make my heart skip a beat 💓"
                isTextarea
              />
              
              <ContentEditor
                label="Certificate Details (Format: Recipient|Giver|Message)"
                contentKey="certificate"
                placeholder="Harshika|Your Love|This certifies that you officially own my heart forever 💖"
              />
            </div>
          )}

          {activeTab === 'media' && (
            <div data-testid="media-section">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Upload Page GIFs & Images</h2>
              
              <MediaUploader label="Entry Page GIF/Image" mediaKey="entry_gif" />
              <MediaUploader label="NO Page GIF/Image" mediaKey="no_page_gif" />
              <MediaUploader label="I Knew It Page GIF/Image" mediaKey="i_knew_it_gif" />
              <MediaUploader label="Proposal Page GIF/Image" mediaKey="proposal_gif" />
              <MediaUploader label="Retry Page GIF/Image" mediaKey="retry_gif" />
              <MediaUploader label="Celebration Page GIF/Image" mediaKey="celebration_gif" />
              <MediaUploader label="Roses Bouquet Image" mediaKey="roses_image" />
            </div>
          )}

          {activeTab === 'gallery' && (
            <div data-testid="gallery-section">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Upload Gallery Photos</h2>
              <p className="text-gray-600 mb-4">Upload multiple photos to create your memory gallery</p>
              
              {[1, 2, 3, 4, 5, 6].map((num) => (
                <MediaUploader
                  key={num}
                  label={`Gallery Photo ${num}`}
                  mediaKey={`gallery_${num}`}
                />
              ))}
            </div>
          )}

          {activeTab === 'audio' && (
            <div data-testid="audio-section">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Upload Background Music</h2>
              <p className="text-gray-600 mb-4">Upload audio that will play in the gallery page</p>
              
              <MediaUploader
                label="Gallery Background Music"
                mediaKey="gallery_audio"
                accept="audio/*"
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
