import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import Confetti from 'react-confetti';
import FloatingHearts from '../components/FloatingHearts';
import { Gift, Heart } from 'lucide-react';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const CelebrationPage = () => {
  const navigate = useNavigate();
  const [windowSize, setWindowSize] = useState({ width: window.innerWidth, height: window.innerHeight });
  const [content, setContent] = useState({ 
    text: "YAYAYAYAY MWAHHHHH MY KUCHU PUCHUUUU 🥹🥀💋\nHERE'S YOUR GIFT 🎁", 
    name: '' 
  });
  const [media, setMedia] = useState(null);

  useEffect(() => {
    fetchContent();
    fetchMedia();
    
    const handleResize = () => {
      setWindowSize({ width: window.innerWidth, height: window.innerHeight });
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const fetchContent = async () => {
    try {
      const response = await axios.get(`${API}/content/celebration_page`);
      const parts = response.data.value.split('|');
      setContent({
        text: parts[0] || "YAYAYAYAY MWAHHHHH MY KUCHU PUCHUUUU 🥹🥀💋\nHERE'S YOUR GIFT 🎁",
        name: parts[1] || ''
      });
    } catch (err) {
      console.log('Using default content');
      setContent({
        text: "YAYAYAYAY MWAHHHHH MY KUCHU PUCHUUUU 🥹🥀💋\nHERE'S YOUR GIFT 🎁",
        name: ''
      });
    }
  };

  const fetchMedia = async () => {
    try {
      const response = await axios.get(`${API}/media/celebration_gif`);
      setMedia(response.data.url);
    } catch (err) {
      console.log('No media uploaded yet');
    }
  };

  const gifts = [
    { id: 1, title: 'Rose Bouquet', path: '/gift/roses', emoji: '🌹', color: 'from-rose-400 to-pink-400' },
    { id: 2, title: 'Our Memories', path: '/gift/gallery', emoji: '📸', color: 'from-purple-400 to-pink-400' },
    { id: 3, title: 'Love Certificate', path: '/gift/certificate', emoji: '📜', color: 'from-amber-400 to-orange-400' }
  ];

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      <Confetti width={windowSize.width} height={windowSize.height} numberOfPieces={300} />
      <FloatingHearts />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6 }}
        className="max-w-2xl w-full bg-white/80 backdrop-blur-md rounded-3xl p-8 shadow-2xl relative z-10"
        data-testid="celebration-page"
      >
        <motion.div
          animate={{ rotate: [0, 10, -10, 0] }}
          transition={{ duration: 0.5, repeat: Infinity, repeatDelay: 2 }}
          className="flex justify-center mb-6"
        >
          <Heart fill="#FF69B4" className="text-pink-500" size={60} />
        </motion.div>

        <motion.h1
          className="text-3xl md:text-4xl font-bold text-center mb-6 dancing-script text-pink-600 whitespace-pre-line"
          data-testid="celebration-text"
        >
          {content.text}
        </motion.h1>

        {media && (
          <div className="mb-8 rounded-2xl overflow-hidden">
            <img
              src={media}
              alt="Celebration"
              className="w-full h-48 object-cover"
              data-testid="celebration-gif"
            />
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {gifts.map((gift, index) => (
            <motion.button
              key={gift.id}
              data-testid={`gift-${gift.id}-button`}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.2 }}
              onClick={() => navigate(gift.path)}
              className={`bg-gradient-to-br ${gift.color} p-6 rounded-2xl shadow-xl hover:shadow-2xl flex flex-col items-center justify-center gap-3`}
              whileHover={{ scale: 1.05, y: -5 }}
              whileTap={{ scale: 0.95 }}
            >
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 1, repeat: Infinity }}
              >
                <Gift size={48} className="text-white" />
              </motion.div>
              <span className="text-4xl">{gift.emoji}</span>
              <span className="text-white font-bold text-lg text-center">{gift.title}</span>
            </motion.button>
          ))}
        </div>
      </motion.div>
    </div>
  );
};

export default CelebrationPage;
