import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Award, Heart } from 'lucide-react';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const CertificatePage = () => {
  const navigate = useNavigate();
  const [certificate, setCertificate] = useState({
    recipient: 'Harshika',
    giver: 'Your Love',
    message: 'This certifies that you officially own my heart forever 💖'
  });

  useEffect(() => {
    fetchContent();
  }, []);

  const fetchContent = async () => {
    try {
      const response = await axios.get(`${API}/content/certificate`);
      const parts = response.data.value.split('|');
      setCertificate({
        recipient: parts[0] || 'Harshika',
        giver: parts[1] || 'Your Love',
        message: parts[2] || 'This certifies that you officially own my heart forever 💖'
      });
    } catch (err) {
      console.log('Using default certificate');
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-100 via-orange-100 to-pink-100 p-4">
      <div className="max-w-4xl mx-auto py-8">
        <motion.button
          data-testid="back-button"
          onClick={() => navigate('/celebration')}
          className="mb-6 flex items-center gap-2 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg hover:shadow-xl print:hidden"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <ArrowLeft size={20} />
          <span className="font-semibold">Back to Gifts</span>
        </motion.button>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          className="bg-white rounded-3xl p-12 shadow-2xl border-8 border-amber-400 relative"
          data-testid="certificate"
        >
          {/* Decorative corners */}
          <div className="absolute top-4 left-4">
            <Heart fill="#f59e0b" className="text-amber-500" size={40} />
          </div>
          <div className="absolute top-4 right-4">
            <Heart fill="#f59e0b" className="text-amber-500" size={40} />
          </div>
          <div className="absolute bottom-4 left-4">
            <Heart fill="#f59e0b" className="text-amber-500" size={40} />
          </div>
          <div className="absolute bottom-4 right-4">
            <Heart fill="#f59e0b" className="text-amber-500" size={40} />
          </div>

          {/* Certificate content */}
          <div className="text-center space-y-6">
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="flex justify-center"
            >
              <Award size={80} className="text-amber-500" />
            </motion.div>

            <h1 className="text-5xl font-bold pacifico text-amber-800">
              Certificate of Love
            </h1>

            <div className="border-t-2 border-b-2 border-amber-300 py-8 space-y-6">
              <p className="text-xl text-gray-700">
                This certificate is awarded to
              </p>
              
              <h2 className="text-4xl font-bold dancing-script text-pink-600" data-testid="certificate-recipient">
                {certificate.recipient}
              </h2>

              <p className="text-lg text-gray-700 max-w-2xl mx-auto leading-relaxed">
                {certificate.message}
              </p>

              <div className="pt-8">
                <p className="text-lg text-gray-600 mb-4">Issued by:</p>
                <div className="border-t-2 border-gray-400 pt-2 max-w-xs mx-auto">
                  <p className="text-2xl font-bold dancing-script text-purple-600" data-testid="certificate-giver">
                    {certificate.giver}
                  </p>
                </div>
              </div>

              <div className="pt-4">
                <p className="text-sm text-gray-500">
                  Date: {new Date().toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}
                </p>
              </div>
            </div>

            <div className="flex gap-4 justify-center pt-6 print:hidden">
              <motion.button
                data-testid="print-certificate-button"
                onClick={handlePrint}
                className="bg-gradient-to-r from-amber-400 to-orange-400 text-white font-bold py-3 px-8 rounded-full shadow-lg hover:shadow-xl"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Print Certificate 🖨️
              </motion.button>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default CertificatePage;
