import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import FloatingHearts from '../components/FloatingHearts';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const EntryPage = () => {
  const navigate = useNavigate();
  const [yesClicks, setYesClicks] = useState(0);
  const [buttonPosition, setButtonPosition] = useState({ x: 0, y: 0 });
  const [content, setContent] = useState({ 
    text: "Hey {name} 🥹 I made something for youuu… wanna see? 💌", 
    name: 'Harshuu' 
  });
  const [media, setMedia] = useState(null);

  useEffect(() => {
    fetchContent();
    fetchMedia();
  }, []);

  const fetchContent = async () => {
    try {
      const response = await axios.get(`${API}/content/entry_page`);
      const parts = response.data.value.split('|');
      setContent({
        text: parts[0] || "Hey {name} 🥹 I made something for youuu… wanna see? 💌",
        name: parts[1] || 'Harshuu'
      });
    } catch (err) {
      console.log('Using default content');
    }
  };

  const fetchMedia = async () => {
    try {
      const response = await axios.get(`${API}/media/entry_gif`);
      setMedia(response.data.url);
    } catch (err) {
      console.log('No media uploaded yet');
    }
  };

  const handleYesClick = () => {
    if (yesClicks < 2) {
      setYesClicks(yesClicks + 1);
    } else {
      navigate('/i-knew-it');
    }
  };

  const handleNoClick = () => {
    navigate('/no-page');
  };

  const moveButton = () => {
    if (yesClicks < 2) {
      const maxX = window.innerWidth - 200;
      const maxY = window.innerHeight - 200;
      setButtonPosition({
        x: Math.random() * maxX,
        y: Math.random() * maxY,
      });
    }
  };

  const displayText = content.text.replace('{name}', content.name);

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      <FloatingHearts />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="max-w-md w-full bg-white/80 backdrop-blur-md rounded-3xl p-8 shadow-2xl relative z-10"
        data-testid="entry-page"
      >
        <motion.h1
          className="text-4xl md:text-5xl font-bold text-center mb-8 dancing-script text-pink-600"
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          {displayText}
        </motion.h1>

        {media && (
          <div className="mb-8 rounded-2xl overflow-hidden">
            <img
              src={media}
              alt="Entry"
              className="w-full h-64 object-cover"
              data-testid="entry-gif"
            />
          </div>
        )}

        <div className="flex flex-col gap-4 items-center relative">
          <motion.button
            data-testid="yes-button"
            onClick={handleYesClick}
            onMouseEnter={moveButton}
            onTouchStart={moveButton}
            style={
              yesClicks < 2 && buttonPosition.x !== 0
                ? {
                    position: 'fixed',
                    left: `${buttonPosition.x}px`,
                    top: `${buttonPosition.y}px`,
                    zIndex: 9999,
                  }
                : {}
            }
            className="bg-gradient-to-r from-pink-400 to-purple-400 text-white font-bold py-4 px-12 rounded-full shadow-lg hover:shadow-xl text-xl"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            💗 YES
          </motion.button>

          <motion.button
            data-testid="no-button"
            onClick={handleNoClick}
            className="bg-white text-pink-500 border-2 border-pink-300 font-bold py-4 px-12 rounded-full shadow-lg hover:bg-pink-50 text-xl"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            🙈 NO
          </motion.button>
        </div>

        {yesClicks > 0 && yesClicks < 2 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6 text-center text-pink-600 font-semibold text-lg"
            data-testid="teasing-message"
          >
            Not sooo easily madam 😏 Try again… or try catching me 💨💘
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};

export default EntryPage;
