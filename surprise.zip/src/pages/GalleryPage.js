import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Music, Play, Pause, Upload } from 'lucide-react';
import { useMusic } from '../contexts/MusicContext';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const GalleryPage = () => {
  const navigate = useNavigate();
  const { isPlaying, playAudio, stopAudio, toggleAudio } = useMusic();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [images, setImages] = useState([]);
  const [messages, setMessages] = useState([]);
  const [audioUrl, setAudioUrl] = useState(null);

  useEffect(() => {
    fetchGalleryData();
    return () => {
      stopAudio();
    };
  }, []);

  const fetchGalleryData = async () => {
    try {
      // Fetch all media
      const mediaResponse = await axios.get(`${API}/media`);
      const galleryImages = mediaResponse.data.filter(m => m.key.startsWith('gallery_'));
      setImages(galleryImages);

      // Fetch audio
      try {
        const audioResponse = await axios.get(`${API}/media/gallery_audio`);
        setAudioUrl(audioResponse.data.url);
        // Auto-play audio when page loads
        playAudio(audioResponse.data.url);
      } catch (err) {
        console.log('No audio uploaded yet');
      }

      // Fetch messages
      try {
        const messagesResponse = await axios.get(`${API}/content/gallery_messages`);
        const messageArray = messagesResponse.data.value.split('|||');
        setMessages(messageArray);
      } catch (err) {
        setMessages([
          'Every moment with you is magical ✨',
          'You make my heart skip a beat 💓',
          'Together forever, my love 💕',
          'You are my happily ever after 🌟'
        ]);
      }
    } catch (err) {
      console.error('Error fetching gallery data:', err);
    }
  };

  const nextImage = () => {
    if (images.length > 0) {
      setCurrentImageIndex((prev) => (prev + 1) % images.length);
    }
  };

  const prevImage = () => {
    if (images.length > 0) {
      setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-200 via-pink-200 to-rose-200 p-4">
      <div className="max-w-4xl mx-auto py-8">
        <div className="flex justify-between items-center mb-6">
          <motion.button
            data-testid="back-button"
            onClick={() => navigate('/celebration')}
            className="flex items-center gap-2 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg hover:shadow-xl"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <ArrowLeft size={20} />
            <span className="font-semibold">Back to Gifts</span>
          </motion.button>

          {audioUrl && (
            <motion.button
              data-testid="music-toggle-button"
              onClick={toggleAudio}
              className="flex items-center gap-2 bg-purple-500 text-white px-4 py-2 rounded-full shadow-lg hover:shadow-xl"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {isPlaying ? <Pause size={20} /> : <Play size={20} />}
              <Music size={20} />
            </motion.button>
          )}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/90 backdrop-blur-md rounded-3xl p-8 shadow-2xl"
          data-testid="gallery-section"
        >
          <h1 className="text-4xl font-bold dancing-script text-purple-600 mb-8 text-center">
            Our Beautiful Memories 💕
          </h1>

          {/* Photo Gallery */}
          <div className="mb-8">
            {images.length > 0 ? (
              <div className="relative">
                <motion.img
                  key={currentImageIndex}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5 }}
                  src={images[currentImageIndex].url}
                  alt={`Memory ${currentImageIndex + 1}`}
                  className="w-full h-96 object-cover rounded-2xl shadow-xl"
                  data-testid="gallery-image"
                />
                
                {images.length > 1 && (
                  <div className="flex justify-center gap-4 mt-4">
                    <button
                      data-testid="prev-image-button"
                      onClick={prevImage}
                      className="bg-purple-500 text-white px-6 py-2 rounded-full shadow-lg hover:bg-purple-600"
                    >
                      ← Previous
                    </button>
                    <span className="flex items-center px-4 py-2 bg-white rounded-full shadow">
                      {currentImageIndex + 1} / {images.length}
                    </span>
                    <button
                      data-testid="next-image-button"
                      onClick={nextImage}
                      className="bg-purple-500 text-white px-6 py-2 rounded-full shadow-lg hover:bg-purple-600"
                    >
                      Next →
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="bg-purple-100 rounded-2xl p-12 text-center">
                <Upload size={48} className="mx-auto mb-4 text-purple-400" />
                <p className="text-purple-600 text-lg">
                  Upload photos from the admin panel to create your gallery! 📸
                </p>
              </div>
            )}
          </div>

          {/* Scrolling Messages */}
          <div className="space-y-6" data-testid="messages-section">
            <h2 className="text-2xl font-bold dancing-script text-pink-600 text-center mb-4">
              Messages from the Heart 💌
            </h2>
            {messages.map((message, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.2 }}
                className={`bg-gradient-to-r ${
                  index % 2 === 0 ? 'from-pink-100 to-purple-100' : 'from-purple-100 to-pink-100'
                } p-6 rounded-2xl shadow-lg`}
              >
                <p className="text-lg text-gray-800 font-medium text-center">
                  {message}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default GalleryPage;
