import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import Confetti from 'react-confetti';
import FloatingHearts from '../components/FloatingHearts';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const IKnewItPage = () => {
  const navigate = useNavigate();
  const [windowSize, setWindowSize] = useState({ width: window.innerWidth, height: window.innerHeight });
  const [content, setContent] = useState({ 
    text: "YAYAYAA I knew you would click that 😌 That's my girl 💖", 
    name: '' 
  });
  const [media, setMedia] = useState(null);

  useEffect(() => {
    fetchContent();
    fetchMedia();
    
    const handleResize = () => {
      setWindowSize({ width: window.innerWidth, height: window.innerHeight });
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const fetchContent = async () => {
    try {
      const response = await axios.get(`${API}/content/i_knew_it_page`);
      const parts = response.data.value.split('|');
      setContent({
        text: parts[0] || "YAYAYAA I knew you would click that 😌 That's my girl 💖",
        name: parts[1] || ''
      });
    } catch (err) {
      console.log('Using default content');
      setContent({
        text: "YAYAYAA I knew you would click that 😌 That's my girl 💖",
        name: ''
      });
    }
  };

  const fetchMedia = async () => {
    try {
      const response = await axios.get(`${API}/media/i_knew_it_gif`);
      setMedia(response.data.url);
    } catch (err) {
      console.log('No media uploaded yet');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      <Confetti width={windowSize.width} height={windowSize.height} recycle={false} numberOfPieces={500} />
      <FloatingHearts />
      
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-md w-full bg-white/80 backdrop-blur-md rounded-3xl p-8 shadow-2xl relative z-10"
        data-testid="i-knew-it-page"
      >
        <motion.h1
          className="text-4xl md:text-5xl font-bold text-center mb-8 dancing-script text-pink-600"
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 1, repeat: Infinity }}
          data-testid="i-knew-it-text"
        >
          {content.text}
        </motion.h1>

        {media && (
          <div className="mb-8 rounded-2xl overflow-hidden">
            <img
              src={media}
              alt="Celebration"
              className="w-full h-64 object-cover"
              data-testid="i-knew-it-gif"
            />
          </div>
        )}

        <motion.button
          data-testid="next-button"
          onClick={() => navigate('/proposal')}
          className="w-full bg-gradient-to-r from-pink-400 to-purple-400 text-white font-bold py-4 px-8 rounded-full shadow-lg hover:shadow-xl text-xl"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Next ➡️
        </motion.button>
      </motion.div>
    </div>
  );
};

export default IKnewItPage;
