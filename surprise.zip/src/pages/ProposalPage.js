import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import FloatingHearts from '../components/FloatingHearts';
import { Sparkles } from 'lucide-react';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const ProposalPage = () => {
  const navigate = useNavigate();
  const [content, setContent] = useState({ 
    text: "{name}… will you be mainee? 🥹👉🏻👈🏻💍", 
    name: 'Harshika' 
  });
  const [media, setMedia] = useState(null);

  useEffect(() => {
    fetchContent();
    fetchMedia();
  }, []);

  const fetchContent = async () => {
    try {
      const response = await axios.get(`${API}/content/proposal_page`);
      const parts = response.data.value.split('|');
      setContent({
        text: parts[0] || "{name}… will you be mainee? 🥹👉🏻👈🏻💍",
        name: parts[1] || 'Harshika'
      });
    } catch (err) {
      console.log('Using default content');
      setContent({
        text: "{name}… will you be mainee? 🥹👉🏻👈🏻💍",
        name: 'Harshika'
      });
    }
  };

  const fetchMedia = async () => {
    try {
      const response = await axios.get(`${API}/media/proposal_gif`);
      setMedia(response.data.url);
    } catch (err) {
      console.log('No media uploaded yet');
    }
  };

  const displayText = content.text.replace('{name}', content.name);

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-800">
      <FloatingHearts />
      
      {/* Glowing stars */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(30)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              opacity: [0, 1, 0],
              scale: [0, 1, 0],
            }}
            transition={{
              duration: 2 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          >
            <Sparkles className="text-yellow-200" size={10 + Math.random() * 20} />
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="max-w-md w-full bg-white/90 backdrop-blur-md rounded-3xl p-8 shadow-2xl relative z-10"
        data-testid="proposal-page"
      >
        <motion.h1
          className="text-4xl md:text-5xl font-bold text-center mb-8 dancing-script gradient-text"
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
          data-testid="proposal-text"
        >
          {displayText}
        </motion.h1>

        {media && (
          <div className="mb-8 rounded-2xl overflow-hidden">
            <img
              src={media}
              alt="Proposal"
              className="w-full h-64 object-cover"
              data-testid="proposal-gif"
            />
          </div>
        )}

        <div className="flex flex-col gap-4">
          <motion.button
            data-testid="yes-proposal-button"
            onClick={() => navigate('/celebration')}
            className="w-full bg-gradient-to-r from-pink-400 to-purple-400 text-white font-bold py-4 px-8 rounded-full shadow-lg hover:shadow-xl text-xl"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            💞 How can I say no
          </motion.button>

          <motion.button
            data-testid="no-proposal-button"
            onClick={() => navigate('/retry')}
            className="w-full bg-white text-pink-500 border-2 border-pink-300 font-bold py-4 px-8 rounded-full hover:bg-pink-50 text-xl"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            😌 No, I'm good
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
};

export default ProposalPage;
