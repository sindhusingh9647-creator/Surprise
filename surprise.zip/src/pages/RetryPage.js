import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import FloatingHearts from '../components/FloatingHearts';
import { HeartCrack } from 'lucide-react';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const RetryPage = () => {
  const navigate = useNavigate();
  const [content, setContent] = useState('Did you just say nooo bachaaa 🥺💔');
  const [media, setMedia] = useState(null);

  useEffect(() => {
    fetchContent();
    fetchMedia();
  }, []);

  const fetchContent = async () => {
    try {
      const response = await axios.get(`${API}/content/retry_page`);
      setContent(response.data.value);
    } catch (err) {
      console.log('Using default content');
    }
  };

  const fetchMedia = async () => {
    try {
      const response = await axios.get(`${API}/media/retry_gif`);
      setMedia(response.data.url);
    } catch (err) {
      console.log('No media uploaded yet');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden bg-gradient-to-br from-blue-200 to-purple-200">
      <FloatingHearts />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ type: 'spring', duration: 0.8 }}
        className="max-w-md w-full bg-white/90 backdrop-blur-md rounded-3xl p-8 shadow-2xl relative z-10"
        data-testid="retry-page"
      >
        <motion.div
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 1, repeat: Infinity }}
          className="flex justify-center mb-6"
        >
          <HeartCrack size={80} className="text-blue-400" />
        </motion.div>

        <motion.h1
          className="text-4xl md:text-5xl font-bold text-center mb-8 dancing-script text-blue-600"
          data-testid="retry-text"
        >
          {content}
        </motion.h1>

        {media && (
          <div className="mb-8 rounded-2xl overflow-hidden">
            <img
              src={media}
              alt="Sad reaction"
              className="w-full h-64 object-cover"
              data-testid="retry-gif"
            />
          </div>
        )}

        <motion.button
          data-testid="retry-button"
          onClick={() => navigate('/proposal')}
          className="w-full bg-gradient-to-r from-blue-400 to-purple-400 text-white font-bold py-4 px-8 rounded-full shadow-lg hover:shadow-xl text-xl"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Try again 😭
        </motion.button>
      </motion.div>
    </div>
  );
};

export default RetryPage;
