import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const RosesPage = () => {
  const navigate = useNavigate();
  const [loveLetter, setLoveLetter] = useState('');
  const [media, setMedia] = useState(null);

  useEffect(() => {
    fetchContent();
    fetchMedia();
  }, []);

  const fetchContent = async () => {
    try {
      const response = await axios.get(`${API}/content/roses_letter`);
      setLoveLetter(response.data.value);
    } catch (err) {
      setLoveLetter('My dearest love,\n\nEvery moment with you is a precious gift. You bring color to my world like these roses bring beauty to a garden. Thank you for being mine.\n\nForever yours 💕');
    }
  };

  const fetchMedia = async () => {
    try {
      const response = await axios.get(`${API}/media/roses_image`);
      setMedia(response.data.url);
    } catch (err) {
      console.log('No media uploaded yet');
    }
  };

  // Falling petals animation
  const petals = Array.from({ length: 20 }, (_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    delay: Math.random() * 5,
    duration: 10 + Math.random() * 5
  }));

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-100 via-pink-100 to-red-100 p-4 relative overflow-hidden">
      {/* Falling petals */}
      {petals.map((petal) => (
        <motion.div
          key={petal.id}
          className="absolute text-3xl pointer-events-none"
          style={{ left: petal.left, top: '-50px' }}
          animate={{
            y: [0, window.innerHeight + 100],
            rotate: [0, 360],
            opacity: [0.8, 0]
          }}
          transition={{
            duration: petal.duration,
            delay: petal.delay,
            repeat: Infinity,
            ease: 'linear'
          }}
        >
          🌹
        </motion.div>
      ))}

      <div className="max-w-4xl mx-auto py-8 relative z-10">
        <motion.button
          data-testid="back-button"
          onClick={() => navigate('/celebration')}
          className="mb-6 flex items-center gap-2 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg hover:shadow-xl"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <ArrowLeft size={20} />
          <span className="font-semibold">Back to Gifts</span>
        </motion.button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Left side - Roses */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="bg-white/80 backdrop-blur-md rounded-3xl p-6 shadow-2xl"
            data-testid="roses-section"
          >
            <h2 className="text-3xl font-bold dancing-script text-rose-600 mb-4 text-center">
              A Bouquet for You 🌹
            </h2>
            {media ? (
              <img
                src={media}
                alt="Rose Bouquet"
                className="w-full h-96 object-cover rounded-2xl"
                data-testid="roses-image"
              />
            ) : (
              <div className="grid grid-cols-3 gap-4">
                {[...Array(9)].map((_, i) => (
                  <motion.div
                    key={i}
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 2, delay: i * 0.1, repeat: Infinity }}
                    className="text-6xl text-center"
                  >
                    🌹
                  </motion.div>
                ))}
              </div>
            )}
          </motion.div>

          {/* Right side - Love Letter */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-amber-50/90 backdrop-blur-md rounded-3xl p-8 shadow-2xl border-4 border-amber-200"
            data-testid="love-letter-section"
          >
            <h2 className="text-3xl font-bold dancing-script text-amber-800 mb-6 text-center">
              Love Letter 💌
            </h2>
            <div className="text-lg text-amber-900 leading-relaxed whitespace-pre-line font-serif">
              {loveLetter}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default RosesPage;
